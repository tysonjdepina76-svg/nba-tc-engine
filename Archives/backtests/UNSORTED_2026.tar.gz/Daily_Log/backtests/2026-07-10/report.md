# TC Backtest Report — BOTH

**Generated:** 2026-07-11 22:18:20 
**Date range:** 2026-07-10
**Total picks graded:** 2
**DK combo lines fetched:** 0
**TC vs DK cross-ref matches:** 0

## Methodology

| Parameter | Value |
|---|---|
| CONS (PTS/REB/AST/3PM) | 0.85x |
| CONS (STL/BLK) | 0.8x |
| Bayesian shrinkage | ON |
| Team-pace adjustment | ON |
| B2B adjustment | ON |
| Starter gate (min 12 min) | ON |
| Grade window | ±0.1 PUSH |

## Overall Hit Rate

**50.0%** (1/2 graded)  |  Pushes: 0

## Hit Rate by Stat

| Stat | Picks | Hit | Miss | Push | Hit% |
|---|---:|---:|---:|---:|---:|
| PTS | 2 | 1 | 1 | 0 | 50.0% |

## Hit Rate by Team

| Team | Picks | Hit | Miss | Push | Hit% |
|---|---:|---:|---:|---:|---:|
| TOR | 1 | 1 | 0 | 0 | 100.0% |
| GS | 1 | 0 | 1 | 0 | 0.0% |

## Hit Rate by Matchup

| Matchup | Picks | Hit | Miss | Push | Hit% |
|---|---:|---:|---:|---:|---:|
| DAL@TOR | 1 | 1 | 0 | 0 | 100.0% |
| GS@CON | 1 | 0 | 1 | 0 | 0.0% |

## Recent Projections (last 40)

| Date | Matchup | Player | Stat | TC | Actual | Diff | Result |
|---|---|---|---|---:|---:|---:|---|
| 2026-07-10 | DAL@TOR | Marina Mabrey (TOR) | PTS | 17.7 | 34 | +16.3 | 🟢 HIT |
| 2026-07-10 | GS@CON | Ashten Prechtel (GS) | PTS | 25.0 | 0.0 | -25.0 | 🔴 MISS |

## Output Files

| File | Description |
|---|---|
| `2026-07-10/report.md` | This report |
| `2026-07-10/historical_raw.json` | Raw Odds API historical response |
| `2026-07-10/scores_raw.json` | Raw Odds API scores response |
| `2026-07-10/espn_actuals.json` | Parsed ESPN box score actuals |
| `2026-07-10/projections.csv` | Full TC projections CSV |
| `2026-07-10/projections.json` | Full TC projections JSON |
| `2026-07-10/edges.json` | TC-vs-DK edge cross-reference |
| `2026-07-10/summary.json` | Summary statistics |
