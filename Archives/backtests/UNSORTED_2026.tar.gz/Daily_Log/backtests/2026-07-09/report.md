# TC Backtest Report — BOTH

**Generated:** 2026-07-11 22:18:31 
**Date range:** 2026-07-09
**Total picks graded:** 0
**DK combo lines fetched:** 0
**TC vs DK cross-ref matches:** 0

## Methodology

| Parameter | Value |
|---|---|
| CONS (PTS/REB/AST/3PM) | 0.85x |
| CONS (STL/BLK) | 0.8x |
| Bayesian shrinkage | ON |
| Team-pace adjustment | ON |
| B2B adjustment | ON |
| Starter gate (min 12 min) | ON |
| Grade window | ±0.1 PUSH |

## Overall Hit Rate

**—** (0/0 graded)  |  Pushes: 0

## Hit Rate by Stat

| Stat | Picks | Hit | Miss | Push | Hit% |
|---|---:|---:|---:|---:|---:|

## Hit Rate by Team

| Team | Picks | Hit | Miss | Push | Hit% |
|---|---:|---:|---:|---:|---:|

## Hit Rate by Matchup

| Matchup | Picks | Hit | Miss | Push | Hit% |
|---|---:|---:|---:|---:|---:|

## Recent Projections (last 40)

| Date | Matchup | Player | Stat | TC | Actual | Diff | Result |
|---|---|---|---|---:|---:|---:|---|

## Output Files

| File | Description |
|---|---|
| `2026-07-09/report.md` | This report |
| `2026-07-09/historical_raw.json` | Raw Odds API historical response |
| `2026-07-09/scores_raw.json` | Raw Odds API scores response |
| `2026-07-09/espn_actuals.json` | Parsed ESPN box score actuals |
| `2026-07-09/projections.csv` | Full TC projections CSV |
| `2026-07-09/projections.json` | Full TC projections JSON |
| `2026-07-09/edges.json` | TC-vs-DK edge cross-reference |
| `2026-07-09/summary.json` | Summary statistics |
