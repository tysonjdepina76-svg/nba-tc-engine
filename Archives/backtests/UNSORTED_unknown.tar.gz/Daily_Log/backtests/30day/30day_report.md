# TC 30-Day Backtest — All Sports
**Generated:** 2026-07-13 14:48
**Picks analyzed:** 0 settled (of 19505 total) from 22 dates

## Hit Rates by Stat
| Stat | Picks | Hit Rate | Avg Edge |
|------|-------|----------|----------|
| PTS | 0 | 0% | 0 |
| REB | 0 | 0% | 0 |
| AST | 0 | 0% | 0 |
| 3PM | 0 | 0% | 0 |
| STL | 0 | 0% | 0 |
| BLK | 0 | 0% | 0 |

## Hit Rates by Direction
| Dir | Picks | Hit Rate | Avg Edge |
|-----|-------|----------|----------|

## Hit Rates by Edge Tier
| Tier | Picks | Hit Rate | Avg Edge |
|------|-------|----------|----------|

## Hit Rates by Team (top 12)
| Team | Picks | Hit Rate | Avg Edge |
|------|-------|----------|----------|
